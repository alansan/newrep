**To delete a virtual interface**

The following ``delete-virtual-interface`` command deletes the specified virtual interface::

  aws directconnect delete-virtual-interface --virtual-interface-id dxvif-ffhhk74f

Output::

  {
      "virtualInterfaceState": "deleting"
  }